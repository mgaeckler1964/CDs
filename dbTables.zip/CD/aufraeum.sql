/*
Alias: ARBEIT
LiveAnswer: FALSE

*/

select *
from titel
where not exists
(
	select * from cd
    where cd.id = titel.cd
)
