/*
Alias: ARBEIT
LiveAnswer: FALSE

*/

select distinct c.interpret as cdInterpret,
				c.titel as cdTitel,
       			t.nummer,
                t.titel as songTitel,
                t.interpret as songInterpret
from   cd c, titel t, bericht b
where	b.cd = c.id and
		c.id = t.cd and
        b.titel = t.nummer and
        b.bericht = 1.0
order by c.interpret, c.titel, t.nummer

