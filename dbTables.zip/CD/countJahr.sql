/*

Answer: :PRIVAT:ANTWORT.DB
Type: PARADOX
Constrained: False
AuxTables: True
RunMode: Vorgabe
Alias: WORK
LiveAnswer: FALSE

*/

SELECT Erscheinungsdatum, COUNT(*) AS AnzahlCDs
FROM "Cd.db"
GROUP BY Erscheinungsdatum
ORDER BY AnzahlCDs desc, Erscheinungsdatum
